<!DOCTYPE html>
<html lang="en">
<head>
    <title>Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Employee Dashboard</h2>
        <a href="<?= base_url('EmployeeController/add') ?>" class="btn btn-primary">+ Add Employee</a>
    </div>

    <div class="row row-cols-1 row-cols-md-2 g-4 mb-5">
        <?php foreach ($employees as $emp): ?>
            <div class="col">
                <div class="card shadow-sm h-100">
                    <?php if ($emp->picture): ?>
                        <img src="<?= base_url('uploads/'.$emp->picture) ?>" class="card-img-top" style="height:200px; object-fit:cover;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?= $emp->name ?></h5>
                        <p class="card-text"><?= $emp->designation ?></p>
                        <p class="card-text"><strong>Salary:</strong> ₹<?= $emp->salary ?></p>
                        <p class="card-text"><small class="text-muted"><?= $emp->address ?></small></p>
                        <a href="<?= base_url('EmployeeController/edit/'.$emp->id) ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                        <a href="<?= base_url('EmployeeController/delete/'.$emp->id) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
