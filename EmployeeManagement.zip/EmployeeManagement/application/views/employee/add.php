<!DOCTYPE html>
<html>
<head>
    <title><?= isset($emp) ? 'Edit' : 'Add' ?> Employee</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h2><?= isset($emp) ? 'Edit' : 'Add New' ?> Employee</h2>
    <form action="<?= isset($emp) ? base_url('EmployeeController/update/'.$emp->id) : base_url('EmployeeController/store') ?>" method="post" enctype="multipart/form-data" class="mt-4">
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?= @$emp->name ?>" required>
        </div>
        <div class="mb-3">
            <label>Address</label>
            <textarea name="address" class="form-control"><?= @$emp->address ?></textarea>
        </div>
        <div class="mb-3">
            <label>Designation</label>
            <input type="text" name="designation" class="form-control" value="<?= @$emp->designation ?>">
        </div>
        <div class="mb-3">
            <label>Salary</label>
            <input type="number" name="salary" class="form-control" value="<?= @$emp->salary ?>">
        </div>
        <div class="mb-3">
            <label>Picture</label>
            <input type="file" name="picture" class="form-control">
            <?php if (@$emp->picture): ?>
                <img src="<?= base_url('uploads/'.$emp->picture) ?>" height="80" class="mt-2">
            <?php endif; ?>
        </div>
        <button type="submit" class="btn btn-success"><?= isset($emp) ? 'Update' : 'Save' ?></button>
        <a href="<?= base_url('EmployeeController') ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
