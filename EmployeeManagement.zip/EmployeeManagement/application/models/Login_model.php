<?php
class Login_model extends CI_Model {

    public function check_user($username)
    {
        
        return $this->db->where('user_name', $username)
                        ->get('login_details')
                        ->row();
       

    }
}
