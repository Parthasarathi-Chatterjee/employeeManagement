<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class EmployeeController extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->load->library(['session', 'upload']);
        $this->load->helper(['url', 'form']);
        $this->load->model('Employee_model');
    }

    public function index()
    {
        $data['employees'] = $this->Employee_model->get_all();
        $this->load->view('employee/dashboard', $data);
    }

    public function add()
    {
        $this->load->view('employee/add');
    }

    public function store()
    {
        $data = $this->input->post();

      if ($_FILES['picture']['name']) {
    $config['upload_path']   = FCPATH . 'uploads/';
    $config['allowed_types'] = 'jpg|jpeg|png';
    $config['file_name']     = time();
    $config['max_size']      = 2048; 

    $this->upload->initialize($config);

    if ($this->upload->do_upload('picture')) {
        $data['picture'] = $this->upload->data('file_name');
    } else {
        echo $this->upload->display_errors();
        die;
    }
}


        $this->Employee_model->insert($data);
        redirect('EmployeeController');
    }

    public function edit($id)
    {
        $data['emp'] = $this->Employee_model->get($id);
        $this->load->view('employee/add', $data);
    }

    public function update($id)
    {
        $data = $this->input->post();

        if ($_FILES['picture']['name']) {
            $config['upload_path']   = './uploads/';
            $config['allowed_types'] = 'jpg|jpeg|png';
            $config['file_name']     = time();
            $config['max_size']      = 2048; 
            $this->upload->initialize($config);
            if ($this->upload->do_upload('picture')) {
                $data['picture'] = $this->upload->data('file_name');
            }
        }

        $this->Employee_model->update($id, $data);
        redirect('EmployeeController');
    }

    public function delete($id)
    {
        $this->Employee_model->delete($id);
        redirect('EmployeeController');
    }
}
